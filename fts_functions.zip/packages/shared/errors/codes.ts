/**
 * Единый словарь кодов ошибок, которые уходят клиенту.
 * Используется на бэкенде (типизированные исключения) и на фронтенде
 * (словарь переводов `errors.json`).
 */
// prettier-ignore
export const ErrorCode = {
  // Service-layer domain invariants
  TYPE_CATEGORY_MISMATCH:           'TYPE_CATEGORY_MISMATCH',
  USER_ROLE_MISMATCH:               'USER_ROLE_MISMATCH',
  SELF_LOOP_FORBIDDEN:              'SELF_LOOP_FORBIDDEN',
  DUPLICATE_TREE_EDGE:              'DUPLICATE_TREE_EDGE',
  FUNCTION_NAME_DUPLICATE:          'FUNCTION_NAME_DUPLICATE',

  // Resource not found
  FTS_FUNCTION_NOT_FOUND:           'FTS_FUNCTION_NOT_FOUND',
  FTS_FUNCTION_DETAIL_NOT_FOUND:    'FTS_FUNCTION_DETAIL_NOT_FOUND',
  FTS_FUNCTION_TREE_EDGE_NOT_FOUND: 'FTS_FUNCTION_TREE_EDGE_NOT_FOUND',
  FTS_FUNCTION_DTI_LINK_NOT_FOUND:  'FTS_FUNCTION_DTI_LINK_NOT_FOUND',
  TYPE_NOT_FOUND:                   'TYPE_NOT_FOUND',
  USER_NOT_FOUND:                   'USER_NOT_FOUND',
  RESOURCE_NOT_FOUND:               'RESOURCE_NOT_FOUND',

  // Generic / infra
  UNIQUE_CONSTRAINT:                'UNIQUE_CONSTRAINT',
  FOREIGN_KEY_CONSTRAINT:           'FOREIGN_KEY_CONSTRAINT',
  VALIDATION_ERROR:                 'VALIDATION_ERROR',
  INVALID_CURSOR:                   'INVALID_CURSOR',
  HTTP_EXCEPTION:                   'HTTP_EXCEPTION',
  INTERNAL_SERVER_ERROR:            'INTERNAL_SERVER_ERROR',

  // Auth
  INVALID_CREDENTIALS:              'INVALID_CREDENTIALS',
  EMAIL_ALREADY_REGISTERED:         'EMAIL_ALREADY_REGISTERED',
  EMAIL_NOT_VERIFIED:               'EMAIL_NOT_VERIFIED',
  EMAIL_VERIFICATION_REQUIRED:      'EMAIL_VERIFICATION_REQUIRED',
  INVALID_TOKEN:                    'INVALID_TOKEN',
  TOKEN_EXPIRED:                    'TOKEN_EXPIRED',
} as const;

export type ErrorCode = (typeof ErrorCode)[keyof typeof ErrorCode];
