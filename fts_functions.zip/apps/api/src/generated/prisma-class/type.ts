import { FtsFunctionToDti } from './fts_function_to_dti'
import { FeedbackToFeedbackSource } from './feedback_to_feedback_source'
import { FtsFunction } from './fts_function'
import { FtsFunctionDetail } from './fts_function_detail'
import { Feedback } from './feedback'
import { FtsFunctionTree } from './fts_function_tree'
import { Action } from './action'
import { Category } from '@prisma/client'
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'

export class Type {
	@ApiProperty({ type: Number })
	id: number

	@ApiProperty({ type: String })
	code: string

	@ApiProperty({ enum: Category, enumName: 'Category' })
	category: Category

	@ApiProperty({ type: String })
	name: string

	@ApiPropertyOptional({ type: String })
	description?: string

	@ApiPropertyOptional({ type: String })
	color?: string

	@ApiPropertyOptional({ type: Number })
	supertypeId?: number

	@ApiPropertyOptional({ type: () => Type })
	supertype?: Type

	@ApiProperty({ isArray: true, type: () => Type })
	subtypes: Type[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionToDti })
	ftsFunctions: FtsFunctionToDti[]

	@ApiProperty({ isArray: true, type: () => FeedbackToFeedbackSource })
	feedbackSourcesToFeedback: FeedbackToFeedbackSource[]

	@ApiProperty({ isArray: true, type: () => FtsFunction })
	ftsCentralizationToFtsFunctions: FtsFunction[]

	@ApiProperty({ isArray: true, type: () => FtsFunction })
	ftsFunctionNameToFtsFunctions: FtsFunction[]

	@ApiProperty({ isArray: true, type: () => FtsFunction })
	competencyCenterToFtsFunctions: FtsFunction[]

	@ApiProperty({ isArray: true, type: () => FtsFunction })
	ftsFunctionMarkerToFtsFunctions: FtsFunction[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionDetail })
	ftsFunctionStepToFtsFunctionDetails: FtsFunctionDetail[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionDetail })
	ftsFunctionCategoryToFtsFunctionDetails: FtsFunctionDetail[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionDetail })
	ftsFunctionComplexityToFtsFunctionDetails: FtsFunctionDetail[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionDetail })
	ftsFunctionExecutionFrequencyToFtsFunctionDetails: FtsFunctionDetail[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionDetail })
	whoPerformsActionToFtsFunctionDetails: FtsFunctionDetail[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionDetail })
	ftsFunctionActionTypeToFtsFunctionDetails: FtsFunctionDetail[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionDetail })
	ftsFunctionEffectivenessToFtsFunctionDetails: FtsFunctionDetail[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionDetail })
	technologicalSolutionToFtsFunctionDetails: FtsFunctionDetail[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionDetail })
	responsibleToFtsFunctionDetails: FtsFunctionDetail[]

	@ApiProperty({ isArray: true, type: () => Feedback })
	ftsMethodologyStatusToFeedback: Feedback[]

	@ApiProperty({ isArray: true, type: () => Feedback })
	feedbackQualityMetricsToFeedback: Feedback[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionTree })
	ftsFunctionTree: FtsFunctionTree[]

	@ApiProperty({ isArray: true, type: () => Action })
	actions: Action[]
}
