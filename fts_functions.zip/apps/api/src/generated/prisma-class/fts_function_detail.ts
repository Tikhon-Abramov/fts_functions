import { FtsFunction } from './fts_function'
import { Type } from './type'
import { Feedback } from './feedback'
import { Action } from './action'
import { FtsFunctionTree } from './fts_function_tree'
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'

export class FtsFunctionDetail {
	@ApiProperty({ type: Number })
	id: number

	@ApiProperty({ type: Number })
	ftsFunctionId: number

	@ApiProperty({ type: Number })
	ftsFunctionStepId: number

	@ApiPropertyOptional({ type: Number })
	ftsFunctionCategoryId?: number

	@ApiPropertyOptional({ type: Number })
	ftsFunctionComplexityId?: number

	@ApiPropertyOptional({ type: Number })
	ftsFunctionExecutionFrequencyId?: number

	@ApiPropertyOptional({ type: Number })
	whoPerformsActionId?: number

	@ApiPropertyOptional({ type: Number })
	ftsFunctionActionTypeId?: number

	@ApiPropertyOptional({ type: Number })
	ftsFunctionEffectivenessId?: number

	@ApiPropertyOptional({ type: Number })
	technologicalSolutionId?: number

	@ApiPropertyOptional({ type: Number })
	responsibleId?: number

	@ApiPropertyOptional({ type: String })
	ftsFunctionDetails?: string

	@ApiPropertyOptional({ type: String })
	basis?: string

	@ApiPropertyOptional({ type: String })
	artifact?: string

	@ApiPropertyOptional({ type: String })
	artifactUsage?: string

	@ApiPropertyOptional({ type: String })
	purpose?: string

	@ApiPropertyOptional({ type: String })
	number?: string

	@ApiPropertyOptional({ type: String })
	algorithm?: string

	@ApiProperty({ type: Date })
	createdAt: Date

	@ApiProperty({ type: Date })
	updatedAt: Date

	@ApiProperty({ type: Boolean })
	isDeleted: boolean

	@ApiPropertyOptional({ type: Date })
	deletedAt?: Date

	@ApiProperty({ type: () => FtsFunction })
	ftsFunction: FtsFunction

	@ApiProperty({ type: () => Type })
	ftsFunctionStep: Type

	@ApiPropertyOptional({ type: () => Type })
	ftsFunctionCategory?: Type

	@ApiPropertyOptional({ type: () => Type })
	ftsFunctionComplexity?: Type

	@ApiPropertyOptional({ type: () => Type })
	ftsFunctionExecutionFrequency?: Type

	@ApiPropertyOptional({ type: () => Type })
	whoPerformsAction?: Type

	@ApiPropertyOptional({ type: () => Type })
	ftsFunctionActionType?: Type

	@ApiPropertyOptional({ type: () => Type })
	ftsFunctionEffectiveness?: Type

	@ApiPropertyOptional({ type: () => Type })
	technologicalSolution?: Type

	@ApiPropertyOptional({ type: () => Type })
	responsible?: Type

	@ApiProperty({ isArray: true, type: () => Feedback })
	feedbacks: Feedback[]

	@ApiProperty({ isArray: true, type: () => Action })
	actions: Action[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionTree })
	parents: FtsFunctionTree[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionTree })
	children: FtsFunctionTree[]
}
