import { FtsFunctionDetail } from './fts_function_detail'
import { Type } from './type'
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'

export class Action {
	@ApiProperty({ type: Number })
	id: number

	@ApiProperty({ type: Number })
	ftsFunctionDetailId: number

	@ApiProperty({ type: Number })
	statusId: number

	@ApiProperty({ type: String })
	description: string

	@ApiProperty({ type: Boolean })
	isDeleted: boolean

	@ApiPropertyOptional({ type: Date })
	deletedAt?: Date

	@ApiProperty({ type: () => FtsFunctionDetail })
	ftsFunctionDetail: FtsFunctionDetail

	@ApiProperty({ type: () => Type })
	status: Type
}
