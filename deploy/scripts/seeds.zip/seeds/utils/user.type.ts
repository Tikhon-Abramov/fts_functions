import { FtsBranchType, FtsFunctionRole, FtsPositionRole, UserRole } from '@prisma-generated/enums';

export type UserType = {
  role: UserRole;
  ftsPositionRole?: FtsPositionRole;
  ftsFunctionRole?: FtsFunctionRole;
  ftsBranchType: FtsBranchType;
  firstName: string;
  lastName: string;
  patronymic?: string;
  description?: string;
};