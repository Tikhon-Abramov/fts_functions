import { HistoryLog } from './history_log'
import { FtsFunction } from './fts_function'
import {
	UserRole,
	FtsPositionRole,
	FtsFunctionRole,
	FtsBranchType,
} from '@prisma/client'
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'

export class User {
	@ApiProperty({ type: Number })
	id: number

	@ApiProperty({ enum: UserRole, enumName: 'UserRole' })
	role: UserRole

	@ApiPropertyOptional({ enum: FtsPositionRole, enumName: 'FtsPositionRole' })
	ftsPositionRole?: FtsPositionRole

	@ApiPropertyOptional({ enum: FtsFunctionRole, enumName: 'FtsFunctionRole' })
	ftsFunctionRole?: FtsFunctionRole

	@ApiProperty({ enum: FtsBranchType, enumName: 'FtsBranchType' })
	ftsBranchType: FtsBranchType

	@ApiProperty({ type: String })
	firstName: string

	@ApiProperty({ type: String })
	lastName: string

	@ApiPropertyOptional({ type: String })
	patronymic?: string

	@ApiPropertyOptional({ type: String })
	fullName?: string

	@ApiPropertyOptional({ type: String })
	shortName?: string

	@ApiPropertyOptional({ type: String })
	description?: string

	@ApiPropertyOptional({ type: String })
	login?: string

	@ApiPropertyOptional({ type: String })
	email?: string

	@ApiPropertyOptional({ type: String })
	passwordHash?: string

	@ApiProperty({ type: Boolean })
	emailVerified: boolean

	@ApiPropertyOptional({ type: String })
	emailVerificationToken?: string

	@ApiPropertyOptional({ type: Date })
	emailVerificationSentAt?: Date

	@ApiPropertyOptional({ type: String })
	passwordResetToken?: string

	@ApiPropertyOptional({ type: Date })
	passwordResetSentAt?: Date

	@ApiPropertyOptional({ type: String })
	avatarKey?: string

	@ApiProperty({ type: Boolean })
	isActive: boolean = true

	@ApiPropertyOptional({ type: Number })
	createdById?: number

	@ApiPropertyOptional({ type: Number })
	updatedById?: number

	@ApiPropertyOptional({ type: Date })
	lastLogin?: Date

	@ApiProperty({ type: Date })
	createdAt: Date

	@ApiProperty({ type: Date })
	updatedAt: Date

	@ApiProperty({ type: Boolean })
	isDeleted: boolean

	@ApiPropertyOptional({ type: Date })
	deletedAt?: Date

	@ApiProperty({ isArray: true, type: () => HistoryLog })
	history: HistoryLog[]

	@ApiProperty({ isArray: true, type: () => FtsFunction })
	curatedFtsFunctions: FtsFunction[]

	@ApiProperty({ isArray: true, type: () => FtsFunction })
	managedFtsFunctions: FtsFunction[]

	@ApiProperty({ isArray: true, type: () => FtsFunction })
	centralOfficeHeadFtsFunctions: FtsFunction[]

	@ApiProperty({ isArray: true, type: () => FtsFunction })
	inspectionHeadFtsFunctions: FtsFunction[]
}
