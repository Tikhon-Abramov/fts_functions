import { Feedback } from './feedback'
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'

export class FtsFunctionDetailAgreementHistory {
	@ApiProperty({ type: Number })
	id: number

	@ApiProperty({ type: Number })
	feedbackId: number

	@ApiPropertyOptional({ type: String })
	fromStatus?: string

	@ApiProperty({ type: String })
	toStatus: string

	@ApiPropertyOptional({ type: String })
	comment?: string

	@ApiProperty({ type: Date })
	createdAt: Date

	@ApiProperty({ type: () => Feedback })
	feedback: Feedback
}
