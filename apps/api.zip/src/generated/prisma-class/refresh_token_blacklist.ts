import { ApiProperty } from '@nestjs/swagger'

export class RefreshTokenBlacklist {
	@ApiProperty({ type: Number })
	id: number

	@ApiProperty({ type: String })
	tokenHash: string

	@ApiProperty({ type: Number })
	userId: number

	@ApiProperty({ type: Date })
	expiresAt: Date

	@ApiProperty({ type: Date })
	createdAt: Date
}
