import { User } from './user'
import { Type } from './type'
import { FtsFunctionToDti } from './fts_function_to_dti'
import { FtsFunctionDetail } from './fts_function_detail'
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'

export class FtsFunction {
	@ApiProperty({ type: Number })
	id: number

	@ApiProperty({ type: Number })
	ftsCentralizationId: number

	@ApiProperty({ type: Number })
	ftsFunctionNameId: number

	@ApiProperty({ type: Number })
	competencyCenterId: number

	@ApiProperty({ type: Number })
	curatorCentralOfficeId: number

	@ApiProperty({ type: Number })
	managerInterregionalInspectionId: number

	@ApiProperty({ type: Number })
	departmentHeadCentralOfficeId: number

	@ApiProperty({ type: Number })
	departmentHeadInterregionalInspectionId: number

	@ApiProperty({ type: Number })
	ftsFunctionMarkerId: number

	@ApiProperty({ type: Date })
	createdAt: Date

	@ApiProperty({ type: Date })
	updatedAt: Date

	@ApiProperty({ type: Boolean })
	isDeleted: boolean

	@ApiPropertyOptional({ type: Date })
	deletedAt?: Date

	@ApiProperty({ type: () => User })
	curatorCentralOffice: User

	@ApiProperty({ type: () => User })
	managerInterregionalInspection: User

	@ApiProperty({ type: () => User })
	departmentHeadCentralOffice: User

	@ApiProperty({ type: () => User })
	departmentHeadInterregionalInspection: User

	@ApiProperty({ type: () => Type })
	ftsCentralization: Type

	@ApiProperty({ type: () => Type })
	ftsFunctionName: Type

	@ApiProperty({ type: () => Type })
	competencyCenter: Type

	@ApiProperty({ type: () => Type })
	ftsFunctionMarker: Type

	@ApiProperty({ isArray: true, type: () => FtsFunctionToDti })
	dtis: FtsFunctionToDti[]

	@ApiProperty({ isArray: true, type: () => FtsFunctionDetail })
	ftsFunctionDetails: FtsFunctionDetail[]
}
