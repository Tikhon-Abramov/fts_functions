import { User as _User } from './user'
import { RefreshTokenBlacklist as _RefreshTokenBlacklist } from './refresh_token_blacklist'
import { AuditLog as _AuditLog } from './audit_log'
import { HistoryLog as _HistoryLog } from './history_log'
import { Type as _Type } from './type'
import { FtsFunctionToDti as _FtsFunctionToDti } from './fts_function_to_dti'
import { FtsFunction as _FtsFunction } from './fts_function'
import { FtsFunctionDetail as _FtsFunctionDetail } from './fts_function_detail'
import { Feedback as _Feedback } from './feedback'
import { FeedbackToFeedbackSource as _FeedbackToFeedbackSource } from './feedback_to_feedback_source'
import { FtsFunctionDetailAgreementHistory as _FtsFunctionDetailAgreementHistory } from './fts_function_detail_agreement_history'
import { FtsFunctionTree as _FtsFunctionTree } from './fts_function_tree'

export namespace PrismaModel {
	export class User extends _User {}
	export class RefreshTokenBlacklist extends _RefreshTokenBlacklist {}
	export class AuditLog extends _AuditLog {}
	export class HistoryLog extends _HistoryLog {}
	export class Type extends _Type {}
	export class FtsFunctionToDti extends _FtsFunctionToDti {}
	export class FtsFunction extends _FtsFunction {}
	export class FtsFunctionDetail extends _FtsFunctionDetail {}
	export class Feedback extends _Feedback {}
	export class FeedbackToFeedbackSource extends _FeedbackToFeedbackSource {}
	export class FtsFunctionDetailAgreementHistory extends _FtsFunctionDetailAgreementHistory {}
	export class FtsFunctionTree extends _FtsFunctionTree {}

	export const extraModels = [
		User,
		RefreshTokenBlacklist,
		AuditLog,
		HistoryLog,
		Type,
		FtsFunctionToDti,
		FtsFunction,
		FtsFunctionDetail,
		Feedback,
		FeedbackToFeedbackSource,
		FtsFunctionDetailAgreementHistory,
		FtsFunctionTree,
	]
}
