import { FtsFunctionDetail } from './fts_function_detail'
import { Type } from './type'
import { ApiProperty } from '@nestjs/swagger'

export class FtsFunctionTree {
	@ApiProperty({ type: Number })
	parentFtsFunctionId: number

	@ApiProperty({ type: Number })
	childFtsFunctionId: number

	@ApiProperty({ type: Number })
	relationTypeId: number

	@ApiProperty({ type: Date })
	createdAt: Date

	@ApiProperty({ type: () => FtsFunctionDetail })
	parentFtsFunction: FtsFunctionDetail

	@ApiProperty({ type: () => FtsFunctionDetail })
	childFtsFunction: FtsFunctionDetail

	@ApiProperty({ type: () => Type })
	relationType: Type
}
