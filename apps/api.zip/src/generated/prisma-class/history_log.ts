import { User } from './user'
import { ActionHistoryType } from '@prisma/client'
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'

export class HistoryLog {
	@ApiProperty({ type: Number })
	id: number

	@ApiProperty({ type: Number })
	userId: number

	@ApiPropertyOptional({ type: String })
	entityType?: string

	@ApiPropertyOptional({ type: Number })
	entityId?: number

	@ApiProperty({ enum: ActionHistoryType, enumName: 'ActionHistoryType' })
	actionType: ActionHistoryType

	@ApiPropertyOptional({ type: Object })
	oldValue?: object

	@ApiProperty({ type: Date })
	createdAt: Date

	@ApiProperty({ type: () => User })
	user: User
}
