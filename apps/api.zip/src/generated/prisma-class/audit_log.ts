import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'

export class AuditLog {
	@ApiProperty({ type: Number })
	id: number

	@ApiPropertyOptional({ type: Number })
	userId?: number

	@ApiProperty({ type: String })
	event: string

	@ApiPropertyOptional({ type: String })
	ipAddress?: string

	@ApiPropertyOptional({ type: String })
	userAgent?: string

	@ApiPropertyOptional({ type: Object })
	metadata?: object

	@ApiProperty({ type: Date })
	createdAt: Date
}
