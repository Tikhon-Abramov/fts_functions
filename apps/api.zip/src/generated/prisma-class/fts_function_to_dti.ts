import { FtsFunction } from './fts_function'
import { Type } from './type'
import { ApiProperty } from '@nestjs/swagger'

export class FtsFunctionToDti {
	@ApiProperty({ type: Number })
	ftsFunctionId: number

	@ApiProperty({ type: Number })
	dtiId: number

	@ApiProperty({ type: Date })
	createdAt: Date

	@ApiProperty({ type: () => FtsFunction })
	ftsFunction: FtsFunction

	@ApiProperty({ type: () => Type })
	dti: Type
}
