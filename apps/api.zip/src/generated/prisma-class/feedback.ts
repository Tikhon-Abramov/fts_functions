import { FtsFunctionDetail } from './fts_function_detail'
import { Type } from './type'
import { FeedbackToFeedbackSource } from './feedback_to_feedback_source'
import { FtsFunctionDetailAgreementHistory } from './fts_function_detail_agreement_history'
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'

export class Feedback {
	@ApiProperty({ type: Number })
	id: number

	@ApiProperty({ type: Number })
	ftsFunctionDetailId: number

	@ApiPropertyOptional({ type: Number })
	feedbackQualityMetricsId?: number

	@ApiPropertyOptional({ type: String })
	problemDescription?: string

	@ApiPropertyOptional({ type: String })
	initiatorRequisites?: string

	@ApiPropertyOptional({ type: Number })
	ftsMethodologyStatusId?: number

	@ApiPropertyOptional({ type: Date })
	deadline?: Date

	@ApiPropertyOptional({ type: String })
	initiatorAcceptance?: string

	@ApiPropertyOptional({ type: Boolean })
	isAccepted?: boolean

	@ApiProperty({ type: Boolean })
	isDeleted: boolean

	@ApiPropertyOptional({ type: Date })
	deletedAt?: Date

	@ApiProperty({ type: () => FtsFunctionDetail })
	ftsFunctionDetail: FtsFunctionDetail

	@ApiPropertyOptional({ type: () => Type })
	ftsMethodologyStatus?: Type

	@ApiPropertyOptional({ type: () => Type })
	feedbackQualityMetrics?: Type

	@ApiProperty({ isArray: true, type: () => FeedbackToFeedbackSource })
	feedbackSources: FeedbackToFeedbackSource[]

	@ApiProperty({
		isArray: true,
		type: () => FtsFunctionDetailAgreementHistory,
	})
	feedbackAgreementHistory: FtsFunctionDetailAgreementHistory[]
}
