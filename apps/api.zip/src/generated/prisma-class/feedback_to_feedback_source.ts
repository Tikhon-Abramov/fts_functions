import { Feedback } from './feedback'
import { Type } from './type'
import { ApiProperty } from '@nestjs/swagger'

export class FeedbackToFeedbackSource {
	@ApiProperty({ type: Number })
	feedbackId: number

	@ApiProperty({ type: Number })
	feedbackSourceId: number

	@ApiProperty({ type: Date })
	createdAt: Date

	@ApiProperty({ type: () => Feedback })
	feedback: Feedback

	@ApiProperty({ type: () => Type })
	feedbackSource: Type
}
