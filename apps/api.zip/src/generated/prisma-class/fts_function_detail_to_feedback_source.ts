import { FtsFunctionDetail } from './fts_function_detail'
import { Type } from './type'
import { ApiProperty } from '@nestjs/swagger'

export class FtsFunctionDetailToFeedbackSource {
	@ApiProperty({ type: Number })
	ftsFunctionDetailId: number

	@ApiProperty({ type: Number })
	feedbackSourceId: number

	@ApiProperty({ type: Date })
	createdAt: Date

	@ApiProperty({ type: () => FtsFunctionDetail })
	ftsFunctionDetail: FtsFunctionDetail

	@ApiProperty({ type: () => Type })
	feedbackSource: Type
}
