import type { Row } from "src/entities/fts-function/types";
import type { TypeResponseDto } from "src/shared/api/ftsFunctionsApi";

import { Save } from "@mui/icons-material";
import {
    Autocomplete,
    Box,
    Button,
    Divider,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    TextField,
    Tooltip,
    Typography,
    useTheme,
} from "@mui/material";
import {
    findTypeNameByCode,
} from "src/entities/fts-function/api/mappers";
import {
    areTechnologyRequiredFieldsFilled,
    findTypeByCodeOrName,
    getAlgorithmAttachmentLabel,
    getTypeNameOptionsByCategory,
    hasTechnologicalSolution,
    isActualActionCategory,
} from "src/entities/fts-function/lib/detail-technology";
import { RowField } from "src/entities/fts-function/model";
import { useDownloadDetailAlgorithmFileMutation } from "src/shared/api/ftsFunctionUploadApi";
import { useTranslation } from "src/shared/i18n";
import { FileAttachmentInput } from "src/shared/ui/FileAttachmentInput";
import { FieldLabel } from "src/shared/ui/form/FieldLabel";
import {
    formInputSx,
    formLabelSx,
    formMenuSx,
    formSelectSx,
} from "src/shared/ui/styles/form";

import {
    EXTRA_FIELDS,
    type ExtraFieldConfig,
    FieldKind,
    getFieldLabel,
    PRIMARY_FIELDS,
    TECHNOLOGY_FIELDS,
} from "../lib/extra-fields";

export type RowDraft = Row;

export type RowDetailsEditProps = {
    draft: RowDraft;
    typesAll: TypeResponseDto[];
    algorithmFile: File | null;
    onChangeField: (key: keyof Row, value: string) => void;
    onChangeAlgorithmFile: (file: File | null) => void;
    onSave: () => void;
    onCancel: () => void;
};

function resolveTypeOptions(
    field: ExtraFieldConfig,
    typesAll: TypeResponseDto[],
): TypeResponseDto[] {
    if (!field.typeCategory) return [];

    return typesAll.filter((item) => item.category === field.typeCategory);
}

function resolveAutocompleteOptions(
    field: ExtraFieldConfig,
    typesAll: TypeResponseDto[],
): readonly string[] {
    if (!field.typeCategory) return [];

    return getTypeNameOptionsByCategory(typesAll, field.typeCategory);
}

function getCurrentValue(draft: RowDraft, field: ExtraFieldConfig): string {
    const value = draft[field.key];

    return value === undefined || value === null ? "" : String(value);
}

export function RowDetailsEdit({
                                   draft,
                                   typesAll,
                                   algorithmFile,
                                   onChangeField,
                                   onChangeAlgorithmFile,
                                   onSave,
                                   onCancel,
                               }: RowDetailsEditProps) {
    const { t } = useTranslation();
    const theme = useTheme();
    const c = theme.custom;

    const [downloadDetailAlgorithmFile, { isLoading: isDownloading }] =
        useDownloadDetailAlgorithmFileMutation();

    const isActualAction = isActualActionCategory(draft.category);
    const technologySelected = hasTechnologicalSolution(draft);
    const algorithmLabel = getAlgorithmAttachmentLabel(draft.step);

    const algorithmFilled = Boolean(
        String(draft.algorithm ?? "").trim() || algorithmFile,
    );

    const technologyValid =
        !isActualAction ||
        !technologySelected ||
        Boolean(
            String(draft.number ?? "").trim() &&
            String(draft.responsible ?? "").trim() &&
            algorithmFilled,
        );

    const handleDownloadAlgorithmFile = () => {
        if (!draft.id || !draft.algorithm?.trim() || algorithmFile || isDownloading) {
            return;
        }

        void downloadDetailAlgorithmFile({
            detailId: Number(draft.id),
            fallbackFileName: draft.algorithm,
        });
    };

    const editFields = isActualAction
        ? [...PRIMARY_FIELDS, ...EXTRA_FIELDS, ...TECHNOLOGY_FIELDS]
        : [...PRIMARY_FIELDS, ...EXTRA_FIELDS];

    return (
        <Box
            sx={{
                height: "100%",
                minHeight: 0,
                display: "flex",
                flexDirection: "column",
                bgcolor: c.bgSurface,
            }}
        >
            <Box
                sx={{
                    px: 2,
                    py: 1.25,
                    borderBottom: `1px solid ${c.borderLight}`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    gap: 1,
                    flexShrink: 0,
                }}
            >
                <Box>
                    <Typography
                        variant="caption"
                        sx={{
                            color: c.textSecondary,
                            fontWeight: 600,
                            textTransform: "uppercase",
                            letterSpacing: "0.05em",
                            fontSize: "0.65rem",
                        }}
                    >
                        {"Редактирование сведений"}
                    </Typography>

                    {!technologyValid && (
                        <Typography
                            sx={{
                                color: theme.palette.warning.main,
                                fontSize: "0.68rem",
                                mt: 0.5,
                            }}
                        >
                            {
                                "Если выбрано технологическое решение, заполните номер ПЗ / АЗ, ответственного и прикрепите файл"
                            }
                        </Typography>
                    )}
                </Box>

                <Box sx={{ display: "flex", alignItems: "center", gap: 0.75 }}>
                    <Button
                        size="small"
                        onClick={onCancel}
                        sx={{
                            textTransform: "none",
                            fontSize: "0.72rem",
                            color: c.textSecondary,
                        }}
                    >
                        {"Отмена"}
                    </Button>

                    <Button
                        size="small"
                        variant="contained"
                        onClick={onSave}
                        disabled={!technologyValid}
                        startIcon={<Save sx={{ fontSize: 14 }} />}
                        sx={{
                            textTransform: "none",
                            fontSize: "0.72rem",
                            bgcolor: c.saveBtn,
                            "&:hover": { bgcolor: c.saveBtnHover },
                            "&.Mui-disabled": {
                                bgcolor: c.borderMain,
                                color: c.textDim,
                            },
                        }}
                        data-testid="button-save-details"
                    >
                        {"Сохранить"}
                    </Button>
                </Box>
            </Box>

            <Box
                sx={{
                    flex: 1,
                    overflow: "auto",
                    px: 2,
                    py: 1.5,
                    display: "flex",
                    flexDirection: "column",
                    gap: 1.25,
                }}
            >
                {editFields.map((field, index) => {
                    const isTechnologyBlockStart =
                        field.key === RowField.TECHNOLOGICAL_SOLUTION;

                    return (
                        <Box key={field.key}>
                            {index === PRIMARY_FIELDS.length && (
                                <Divider sx={{ borderColor: c.borderLight, mb: 1.25 }} />
                            )}

                            {isTechnologyBlockStart && (
                                <>
                                    <Divider sx={{ borderColor: c.borderLight, mb: 1.25 }} />


                                </>
                            )}

                            {field.key === RowField.ALGORITHM ? (
                                <FileAttachmentInput
                                    label={algorithmLabel}
                                    fileName={String(draft.algorithm ?? "")}
                                    selectedFile={algorithmFile}
                                    disabled={technologySelected ? false : !isActualAction}
                                    required={technologySelected}
                                    isDownloading={isDownloading}
                                    testId="details-panel-algorithm-file"
                                    onChangeFile={onChangeAlgorithmFile}
                                    onDownloadFile={handleDownloadAlgorithmFile}
                                />
                            ) : (
                                <DraftField
                                    field={field}
                                    draft={draft}
                                    typesAll={typesAll}
                                    disabled={
                                        field.key !== RowField.TECHNOLOGICAL_SOLUTION &&
                                        TECHNOLOGY_FIELDS.some((item) => item.key === field.key) &&
                                        !technologySelected
                                    }
                                    onChangeField={onChangeField}
                                />
                            )}
                        </Box>
                    );
                })}
            </Box>
        </Box>
    );
}

type DraftFieldProps = {
    field: ExtraFieldConfig;
    draft: RowDraft;
    typesAll: TypeResponseDto[];
    disabled: boolean;
    onChangeField: (key: keyof Row, value: string) => void;
};

function DraftField({
                        field,
                        draft,
                        typesAll,
                        disabled,
                        onChangeField,
                    }: DraftFieldProps) {
    const { t } = useTranslation();
    const theme = useTheme();
    const c = theme.custom;

    const label = getFieldLabel(field, t);
    const value = getCurrentValue(draft, field);

    if (field.kind === FieldKind.SELECT_CODE) {
        return (
            <FormControl size="small" fullWidth disabled={disabled}>
                <InputLabel sx={formLabelSx(theme)}>{label}</InputLabel>

                <Select
                    value={value}
                    label={label}
                    onChange={(event) => onChangeField(field.key, String(event.target.value))}
                    sx={formSelectSx(theme)}
                    MenuProps={formMenuSx(theme)}
                    data-testid={field.testId}
                >
                    {(field.options ?? []).map((option) => (
                        <MenuItem
                            key={option.value}
                            value={option.value}
                            sx={{ fontSize: "0.78rem" }}
                        >
                            {findTypeNameByCode(typesAll, option.value)}
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>
        );
    }

    if (field.kind === FieldKind.SELECT_TYPE_CODE) {
        const options = resolveTypeOptions(field, typesAll);

        return (
            <FormControl size="small" fullWidth disabled={disabled}>
                <InputLabel sx={formLabelSx(theme)}>{label}</InputLabel>

                <Select
                    value={value}
                    label={label}
                    onChange={(event) => onChangeField(field.key, String(event.target.value))}
                    sx={formSelectSx(theme)}
                    MenuProps={formMenuSx(theme)}
                    data-testid={field.testId}
                >
                    <MenuItem
                        value=""
                        sx={{
                            fontSize: "0.78rem",
                            fontStyle: "italic",
                            color: c.textDim,
                        }}
                    >
                        {"— не выбрано —"}
                    </MenuItem>

                    {options.map((option) => (
                        <MenuItem
                            key={option.code}
                            value={option.code}
                            sx={{ fontSize: "0.78rem" }}
                        >
                            {option.name}
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>
        );
    }

    if (field.kind === FieldKind.AUTOCOMPLETE_FROM_TYPES) {
        const options = resolveAutocompleteOptions(field, typesAll);

        return (
            <Autocomplete
                freeSolo
                disabled={disabled}
                options={options}
                value={value}
                onChange={(_, nextValue) => onChangeField(field.key, nextValue ?? "")}
                onInputChange={(_, nextValue) => onChangeField(field.key, nextValue)}
                size="small"
                fullWidth
                slotProps={{
                    paper: {
                        sx: {
                            bgcolor: c.bgMenu,
                            color: c.textBody,
                            border: `1px solid ${c.borderMain}`,
                        },
                    },
                    listbox: {
                        sx: {
                            py: 0,
                            "& .MuiAutocomplete-option": {
                                minHeight: 28,
                                fontSize: "0.78rem",
                                py: 0.25,
                            },
                        },
                    },
                }}
                renderOption={(props, option) => {
                    const { key, ...rest } = props as typeof props & { key?: string };

                    return (
                        <Tooltip key={key ?? option} title={option} placement="right">
                            <li {...rest}>{option}</li>
                        </Tooltip>
                    );
                }}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        label={label}
                        sx={formInputSx(theme)}
                        data-testid={field.testId}
                    />
                )}
            />
        );
    }

    return (
        <TextField
            value={value}
            onChange={(event) => onChangeField(field.key, event.target.value)}
            label={label}
            fullWidth
            size="small"
            disabled={disabled}
            multiline={field.kind === FieldKind.TEXTAREA}
            rows={field.kind === FieldKind.TEXTAREA ? 2 : undefined}
            sx={formInputSx(theme)}
            data-testid={field.testId}
        />
    );
}